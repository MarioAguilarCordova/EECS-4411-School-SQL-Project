SELECT * FROM stl.book
ORDER BY genre; 

SELECT * FROM stl.book
ORDER BY bookid;
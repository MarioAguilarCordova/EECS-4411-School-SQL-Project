SELECT * FROM stl.book
  WHERE language = 'French'
  and genre = 'Romance'
  and publisher = 'Random movies'
  and price = 15.35;
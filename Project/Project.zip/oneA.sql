SELECT * FROM stl.book
  WHERE bookid = 400;